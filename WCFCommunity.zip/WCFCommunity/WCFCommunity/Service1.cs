﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;

namespace WCFCommunity
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "Service1" à la fois dans le code et le fichier de configuration.
    public class Service1 : IService1
    {

        OrganizationServiceProxy _orgservice;
        string userName = "hliadmin@diicrm.onmicrosoft.com";
        string passWord = "Operating123";
        string Url = "https://ubitest.api.crm4.dynamics.com/XRMServices/2011/Organization.svc";
        private bool InitializeCRMService(string userName, string passWord, string Url)
        {
            bool isSuccess = false;
            Uri organizationUrl = new Uri(Url);
            ClientCredentials credit = new ClientCredentials();
            credit.UserName.UserName = userName;
            credit.UserName.Password = passWord;
            _orgservice = new OrganizationServiceProxy(organizationUrl, null, credit, null);
            _orgservice.ServiceConfiguration.CurrentServiceEndpoint.EndpointBehaviors.Add(new ProxyTypesBehavior());

            if (_orgservice != null)
                isSuccess = true;
            return isSuccess;

        }
        public string CreateLead(string userlogin)
        {
            Guid newContactId = Guid.Empty;
            if (InitializeCRMService(userName, passWord, Url))
            {
                Entity LeadEntity = new Entity("lead");
                LeadEntity["firstname"] = "testWcf";
                LeadEntity["lastname"] = "17/02";
                LeadEntity["emailaddress1"] = "jaballiyoussef4@gmail.com";
                LeadEntity["subject"] = "Lead Created From Web Service";
                newContactId = _orgservice.Create(LeadEntity);

                return "New Lead Created Id : " + newContactId.ToString();
            }
            else
            {
                return "Record Could Not Be Created :" + newContactId.ToString();
            }
        }
    }
}